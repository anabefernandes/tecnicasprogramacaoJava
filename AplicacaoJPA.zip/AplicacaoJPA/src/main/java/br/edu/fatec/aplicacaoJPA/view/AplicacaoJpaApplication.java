package br.edu.fatec.aplicacaoJPA.view;

import br.edu.fatec.aplicacaoJPA.model.Endereco;
import br.edu.fatec.aplicacaoJPA.model.EnderecoBanco;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.util.Scanner;

@SpringBootApplication
public class AplicacaoJpaApplication implements CommandLineRunner {

	@Autowired
	private EnderecoBanco enderecoBanco;

	public static void main(String[] args) {
		SpringApplication.run(AplicacaoJpaApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		Scanner scanner = new Scanner(System.in);
		int opcaoMenu = -1;

		while (opcaoMenu != 0) {
			exibirMenuPrincipal();
			opcaoMenu = scanner.nextInt();
			scanner.nextLine();

			switch (opcaoMenu) {
				case 1:
					System.out.print("Informe o CEP para consulta: ");
					String cepInput = scanner.nextLine();
					Endereco.addBanco(cepInput, enderecoBanco);
					break;
				case 2:
					System.out.println("Lista de CEPs cadastrados no banco:");
					enderecoBanco.mostrarCepsCadastrados();
					break;
				case 0:
					System.out.println("Encerrando o programa...");
					break;
				default:
					System.out.println("Opção inválida. Tente novamente.");
					break;
			}
			System.out.println("-----------------------------------");
		}
	}

	private void exibirMenuPrincipal() {
		System.out.println("\nSelecione uma opção:");
		System.out.println("1 - Buscar CEP");
		System.out.println("2 - Visualizar CEPs Cadastrados");
		System.out.println("0 - Sair");
		System.out.print("Escolha: ");
	}
}
