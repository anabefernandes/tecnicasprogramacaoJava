package br.edu.fatec.aplicacaoJPA.model;

import br.edu.fatec.aplicacaoJPA.repository.EnderecoRepository;
import jakarta.persistence.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Entity
@Table(name = "ceps")
@Component
public class EnderecoBanco {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(unique = true, nullable = false)
    private String cep;

    @Column(name = "rua")
    private String rua;

    @Column(name = "bairro")
    private String bairro;

    @Column(name = "cidade")
    private String cidade;

    @Column(name = "estado")
    private String uf;

    @Autowired
    private EnderecoRepository repository;

    public EnderecoBanco() {
    }

    public EnderecoBanco(String cep, String rua, String bairro, String cidade, String uf) {
        this.cep = cep;
        this.rua = rua;
        this.bairro = bairro;
        this.cidade = cidade;
        this.uf = uf;
    }

    public EnderecoBanco(Endereco endereco) {
        this.cep = endereco.getCep();
        this.rua = endereco.getRua();
        this.bairro = endereco.getBairro();
        this.cidade = endereco.getCidade();
        this.uf = endereco.getUf();
    }

    public void mostrarCepsCadastrados() {
        List<EnderecoBanco> enderecos = repository.findAll();
        enderecos.forEach(System.out::println);
    }

    public void addBanco(Endereco endereco) {
        if (repository.findByCep(endereco.getCep()).isEmpty()) { // Verifica se o CEP já existe
            EnderecoBanco enderecoBanco = new EnderecoBanco(endereco);
            repository.save(enderecoBanco);
            System.out.println("Endereço salvo com sucesso.");
        } else {
            System.out.println("O CEP já está cadastrado no banco.");
        }
    }

    @Override
    public String toString() {
        return "ENDEREÇO" +
                "\nCEP: " + cep +
                "\nRUA: " + rua +
                "\nBAIRRO: " + bairro +
                "\nCIDADE: " + cidade +
                "\nUF: " + uf;
    }
}
